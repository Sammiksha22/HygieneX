<?php

#http://localhost/safety/hardware.php?id=19.232423@72.343434@1@1


  include "connection.php";
  
  $id = $_REQUEST['id'];

  $reading = explode("@", $id);
  
  $moisture = $reading[0];
  $temp = $reading[1];

  $time = time();
  $sql="INSERT INTO `param`(`moisture`, `time`, `temp`) VALUES ('$moisture','$time','$temp')";

            
 if(mysqli_query($link, $sql))
          {

                  echo "%data added#";
           
          } else{
              echo "ERROR: Could not able to execute $sql. ";
          }


mysqli_close($link);

?>