<?php


  include "connection.php";
  
  $id = $_REQUEST['id'];

            


               $sql="DELETE FROM `clean` WHERE `id` = '$id'; ";
            
              if(mysqli_query($link, $sql))
                {

                  echo"<script> alert('Data deleted') </script>";
                  echo '<script>window.location.href = "clean.php";</script>';

                }
           
          else{
              echo "ERROR: Could not able to execute $sql. ";
          }
          

  
  
   mysqli_close($link);
?>