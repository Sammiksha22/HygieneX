<?php
  
  include "connection.php";

  $readings =  $_REQUEST["sensor"];
  
  $data = explode("@", $readings);
  $smoke = $data[1];
  $roll = $data[0];

  $clean=$data[2];

  if($roll == 1)
  {
    
    $roll = "Finished";

   $fields = array(
            "message" => "Paper Roll Finished, Please Change Roll.",
            "language" => "english",
            "route" => "q",
            "numbers" => "9821971161",
        );

        $curl = curl_init();

        curl_setopt_array($curl, array(
          CURLOPT_URL => "https://www.fast2sms.com/dev/bulkV2",
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 30,
          CURLOPT_SSL_VERIFYHOST => 0,
          CURLOPT_SSL_VERIFYPEER => 0,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "POST",
          CURLOPT_POSTFIELDS => json_encode($fields),
          CURLOPT_HTTPHEADER => array(
            "authorization: YOUR_API_KEY",
            "accept: */*",
            "cache-control: no-cache",
            "content-type: application/json"
          ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);


        curl_close($curl);

        if ($err) {
          echo "cURL Error #:" . $err;
        } else {
          echo $response;
        }


  }else
  {
      $roll = "Not Finished";
  }


  if($smoke == 0)
  {
      $smoke = "Bad";

       $fields = array(
            "message" => "Bad Odour Detected, Please check.",
            "language" => "english",
            "route" => "q",
            "numbers" => "9821971161",
        );

        $curl = curl_init();

        curl_setopt_array($curl, array(
          CURLOPT_URL => "https://www.fast2sms.com/dev/bulkV2",
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 30,
          CURLOPT_SSL_VERIFYHOST => 0,
          CURLOPT_SSL_VERIFYPEER => 0,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "POST",
          CURLOPT_POSTFIELDS => json_encode($fields),
          CURLOPT_HTTPHEADER => array(
            "authorization: YOUR_API_KEY",
            "accept: */*",
            "cache-control: no-cache",
            "content-type: application/json"
          ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);


        curl_close($curl);

        if ($err) {
          echo "cURL Error #:" . $err;
        } else {
          echo $response;
        }

  }else
  {
      $smoke = "Good";
  }

 $time = time();

 $sql="INSERT INTO `paper`(`paper`, `time`) VALUES ('$roll','$time')";
 $retval = mysqli_query( $link, $sql);
   
   if(! $retval ) {
      die('Could not enter data: ' . mysqli_error());
  }

  $sql="INSERT INTO `param`(`air`, `time`) VALUES ('$smoke','$time')";
 $retval = mysqli_query( $link, $sql);
   
   if(! $retval ) {
      die('Could not enter data: ' . mysqli_error());
  }

  if($clean==1)
  {

    $sql="INSERT INTO `clean`(`clean`,`time`) VALUES ('Yes','$time')";
    $retval = mysqli_query( $link, $sql);
     
     if(! $retval ) {
        die('Could not enter data: ' . mysqli_error());
    }
  }

  echo "%data added#";
  mysqli_close($link);
?>